package com.risksense.converters;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
/*
 * This class implements the interface XMLJSONConverter
 */
public class XMLJSONConverter implements XMLJSONConverterI {
	/*
	 * Creating logger with class name.
	 */

	private static final Logger LOGGER = Logger.getLogger (XMLJSONConverter.class.getName ());
	/*
	 * @see com.risksense.converters.XMLJSONConverterI#convertJSONtoXML(java.io.File, java.io.File)
	 * The abstract method in the interface is implemented.
	 */
	@Override
	public void convertJSONtoXML(File json, File xml) throws IOException {
		//The below readfile function is called for reading from file.
		String jsonString = readFile (json);
		//Throw exception/exit if json file is empty
		if (jsonString.isEmpty() || jsonString == null) {
			LOGGER.log (Level.INFO, "JSON string read from file is empty");	
			throw new IOException();
		}
		LOGGER.log (Level.INFO, "json string read from file: \n" + jsonString);
		//JSONMethods class converts json string to xml form and writes it to file
		ConverterMethods jsonMethods = new ConverterMethods();
		jsonMethods.xmlConverter (jsonString, xml);	
		
	}
	public static String readFile (File file) throws IOException {
		LOGGER.log (Level.INFO, "Reading file : " + file.getName());
		BufferedReader fileReader = null;
		try {
			//FileReader opens the file in read mode with the parameter as string
			fileReader = new BufferedReader (new FileReader (file));
		} catch (FileNotFoundException e) {
			//If the file does not exist it throws file not found exception
			LOGGER.log (Level.SEVERE, "File not found exception for " + file.getName());
			throw new IOException();
		}
		//String builder is used for concatenating all the lines from the buffered reader.
		StringBuilder string = new StringBuilder ();
		try {
			String line = fileReader.readLine ();
			while (line != null) {
				string.append (line);
				string.append ("\n");
				line = fileReader.readLine ();
			}
		}catch (IOException e){
			//if the json file cannot be read, throw exception and exit
			LOGGER.log (Level.SEVERE, "Exception while reading file " + file.getName());
			throw new IOException();
		} finally{
			//in case file closing throws IOException, it will be caught in the calling class
			fileReader.close ();
		}
		//file contents returned as string
		return string.toString();
	}
	public static void writeFile (File file, String text) throws IOException  {
		if (text == null || text.isEmpty()) return;
		BufferedWriter fileWriter = null;
		fileWriter = new BufferedWriter (new FileWriter (file));			
		fileWriter.write (text);
		fileWriter.close ();
	}

}
