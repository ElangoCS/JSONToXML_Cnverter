package com.risksense.converters;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class converterMain {
	//This line creates a logger with class name as name.
	private static final Logger LOGGER = Logger.getLogger (converterMain.class.getName ());
	//***Main method for the converter
	public static void main (String []args) {
		//It checks for arguments
		if (args.length != 2||args.length >2) {
			LOGGER.log (Level.SEVERE, "Invalid Number of argumnets.Please give two files");
			} 
		else {
			//Reading filenames from command line arguments
			String jsonFileName = args [0];
			String xmlFileName = args [1];
			//Printing the file name in the console
			LOGGER.log (Level.INFO, "Command line arguments : " + jsonFileName + " " + xmlFileName);
			File jsonFile = new File (jsonFileName);
			File xmlFile = new File (xmlFileName);
			//ConverterFactory returns implementation specific instance of XMLJSONConverterI
			XMLJSONConverterI xmljsonConverter = ConverterFactory.createXMLJSONConverter ();
			try {
					//convertJSONtoXML reads json from file, parses and converts to XML
					xmljsonConverter.convertJSONtoXML (jsonFile, xmlFile);
				} catch (IOException e) {
					LOGGER.log (Level.SEVERE, "Couldn't do conversion!Exception!!!!!!");
			}
		}
	}
}
