package com.risksense.converters;
import java.io.File;
import java.io.IOException;
public interface XMLJSONConverterI {
	/*
	 * This interface implements abstract method for conversion.
	 * As the file might be empty it is extending IOException class.
	 * It throws IOException when error occurs.
	 */
	public void convertJSONtoXML(File json, File xml) throws IOException;
}
