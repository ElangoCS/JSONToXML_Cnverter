package com.risksense.converters;

public class ConverterFactory {
	public static final XMLJSONConverterI createXMLJSONConverter() {
    	//returning instance of XMLJSONConverter
       return new XMLJSONConverter();
}
}
